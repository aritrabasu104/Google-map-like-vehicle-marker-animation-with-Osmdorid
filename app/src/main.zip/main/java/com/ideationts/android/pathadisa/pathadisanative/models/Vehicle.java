package com.ideationts.android.pathadisa.pathadisanative.models;

/**
 * Created by ARITRA on 05-07-2017.
 */

public class Vehicle {
    private String vehicleId;
    private String vehicleRegNo;
    private String vehicleType;
    private String publiclyVisible;
    private String isValid;

    public String getVehicleId() {
        return vehicleId;
    }

    public String getVehicleRegNo() {
        return vehicleRegNo;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getPubliclyVisible() {
        return publiclyVisible;
    }

    public String getIsValid() {
        return isValid;
    }
}
